package ejemploPrismaRectangular;

public class PrincipalPrismaRectangular {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		PrismaRectangular miPrisma = new PrismaRectangular(2.5, 5.3, 4.2);
		System.out.println(miPrisma.toString());
	}
}
