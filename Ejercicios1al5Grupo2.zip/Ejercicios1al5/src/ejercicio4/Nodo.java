package ejercicio4;

public class Nodo {

	 String nombre;
	    Nodo sig;

	    public Nodo(String nombre) {
	        this.nombre = nombre;
	        this.sig = null;
	    }
}
