package ejercicio10;

public class NodoL {
	int dato;
	NodoL siguiente;
	
	public NodoL(int dato) {
		this.dato = dato;
		this.siguiente = null;
	}
}
