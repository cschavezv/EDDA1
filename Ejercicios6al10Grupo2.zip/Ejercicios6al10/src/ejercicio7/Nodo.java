package ejercicio7;

public class Nodo {
	char parentesis;
	Nodo siguiente;
	public Nodo(char parentesis) {
		this.parentesis = parentesis;
		siguiente=null;
	}
	
}
