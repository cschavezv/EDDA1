package ejercicio8;

public class Nodo {
	char letra;
	Nodo siguiente;
	
	public Nodo(char letra) {
		this.letra = letra;
		siguiente = null;
	}
}
