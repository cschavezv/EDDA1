package ejercicio9;

public class NodoL {
	String dato;
	NodoL siguiente;
	
	public NodoL(String dato) {
		this.dato = dato;
		this.siguiente = null;
	}
}
