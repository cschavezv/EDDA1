package Ejercicio2;

public class ArregloNombres {
	
	private static final int longitud = 4;
	private String arreglo [];
	
	public ArregloNombres() {
		for(int i = 0; ) {
			
		}
	}
	
	public ArregloNombres(String[] arreglo) {
		
		this.arreglo = arreglo;
	}
	
	public String[] getArreglo() {
		return arreglo;
	}
	public void setArreglo(String[] arreglo) {
		this.arreglo = arreglo;
	}
	
	
}
