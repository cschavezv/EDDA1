package Ejercicios;

public class ArregloEnterosPrincipal {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArregloEnteros arreglo = new ArregloEnteros();
		System.out.println(arreglo.toString());
	}

}
