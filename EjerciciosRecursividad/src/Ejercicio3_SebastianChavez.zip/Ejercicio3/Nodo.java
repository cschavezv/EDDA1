package Ejercicio3;

public class Nodo {
	int numero;
	Nodo siguiente;
	
	public Nodo(int numero) {
		this.numero = numero;
		this.siguiente = null;
	}
}
